-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 28, 2022 at 06:55 PM
-- Server version: 8.0.21
-- PHP Version: 7.4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `wp_contact_form`
--

DROP TABLE IF EXISTS `wp_contact_form`;
CREATE TABLE IF NOT EXISTS `wp_contact_form` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `wp_contact_form`
--

INSERT INTO `wp_contact_form` (`id`, `firstname`, `lastname`, `email`, `subject`) VALUES
(1, 'Test', 'Test', 'test@gmail.com', 'Test'),
(2, '', 'Test', 'vijayrathod245@gmail.com', 'Test'),
(3, '', 'Test', 'vijayrathod245@gmail.com', 'Test'),
(4, 'Test', 'Test', 'test@gmail.com', 'Test'),
(5, '', '', '', ''),
(6, '', '', '', ''),
(7, '', '', '', ''),
(8, '', '', '', ''),
(9, '', '', '', ''),
(10, '', '', '', ''),
(11, '', '', '', ''),
(12, '', '', '', ''),
(13, '', '', '', ''),
(14, 'Test', 'Test', 'test@gmail.com', 'test'),
(15, 'Test', 'Test', 'test@gmail.com', 'test'),
(16, '', '', '', ''),
(17, '', '', '', ''),
(18, 'Test', 'Test', 'vijayrathod245@gmail.com', 'test'),
(19, 'Test', 'Test', 'vijayrathod245@gmail.com', 'Test'),
(20, 'Test', 'Test', 'test@gmail.com', ''),
(21, 'Test', 'Test', 'vijayrathod245@gmail.com', 'Test'),
(22, 'Vijay', 'Rathod', 'vijayrathod245@gmail.com', 'test'),
(23, 'Vijay', 'Rathod', 'vijayrathod245@gmail.com', 'test');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
